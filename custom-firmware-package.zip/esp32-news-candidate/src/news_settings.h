#pragma once
#include "settings_page.h"

static bool settingsInt(const char* name, int current, int minimum, int maximum, int& value) {
  value=current;
  if (!newsServer.hasArg(name)) return true;
  String text=newsServer.arg(name); if (!text.length()) return false;
  for (unsigned i=0;i<text.length();++i) if (!isdigit(text[i])) return false;
  long number=text.toInt(); if(number<minimum || number>maximum) return false;
  value=number; return true;
}
static bool settingsColor(const char* name,uint32_t current,uint32_t& value) {
  value=current; if(!newsServer.hasArg(name)) return true;
  String text=newsServer.arg(name);
  if(text.length()!=7 || text[0]!='#') return false;
  for(int i=1;i<7;++i) if(!isxdigit(text[i])) return false;
  value=strtoul(text.c_str()+1,nullptr,16); return true;
}
static void updateTextColors() {
  dateTextColor=panelRgb(dateTextRgb);hourTextColor=panelRgb(hourTextRgb);
  minuteTextColor=panelRgb(minuteTextRgb);secondTextColor=panelRgb(secondTextRgb);newsTextColor=panelRgb(newsTextRgb);
}
static void loadNewsSettings() {
  const char* keys[]={"date_rgb","hour_rgb","min_rgb","sec_rgb","news_rgb"};
  uint32_t* values[]={&dateTextRgb,&hourTextRgb,&minuteTextRgb,&secondTextRgb,&newsTextRgb};
  for(int i=0;i<5;++i)*values[i]=newsPrefs.getUInt(keys[i],*values[i])&0xFFFFFF;
  updateTextColors();
  newsPollMs=newsPrefs.getUInt("poll_ms",600000); if(newsPollMs!=600000 && newsPollMs!=1800000)newsPollMs=600000;
  newsScrollMs=newsPrefs.getUInt("scroll_ms",35);if(newsScrollMs<20||newsScrollMs>70)newsScrollMs=35;
  newsLimit=newsPrefs.getUInt("limit",10);if(newsLimit<1||newsLimit>10)newsLimit=10;
  newsCategories=newsPrefs.getUInt("categories",15);if(newsCategories<1||newsCategories>15)newsCategories=15;
  newsSourceMode=newsPrefs.getUInt("source_mode",0);if(newsSourceMode>1)newsSourceMode=0;
  newsShowInfo=newsPrefs.getBool("show_info",true);
  updateweather_time=newsPrefs.getUInt("weather_min",10);if(updateweather_time<10||updateweather_time>60)updateweather_time=10;
}
static void addNewsSettings(JsonDocument& doc) {
  const char* names[]={"date_color","hour_color","minute_color","second_color","news_color"};
  const uint32_t values[]={dateTextRgb,hourTextRgb,minuteTextRgb,secondTextRgb,newsTextRgb};
  for(int i=0;i<5;++i){char hex[8];snprintf(hex,sizeof(hex),"#%06lX",(unsigned long)values[i]);doc[names[i]]=hex;}
  doc["brightness"]=LCD_BL_PWM;doc["rotation"]=LCD_Rotation;doc["city_code"]=cityCode;
  doc["weather_minutes"]=updateweather_time;doc["news_minutes"]=newsPollMs/60000;
  doc["news_limit"]=newsLimit;doc["scroll_ms"]=newsScrollMs;doc["categories"]=newsCategories;
  doc["source_mode"]=newsSourceMode;doc["show_info"]=newsShowInfo;
}
static void handleNewsSettings() {
  uint32_t colors[5]; const char* names[]={"date_color","hour_color","minute_color","second_color","news_color"};
  uint32_t* current[]={&dateTextRgb,&hourTextRgb,&minuteTextRgb,&secondTextRgb,&newsTextRgb};
  for(int i=0;i<5;++i)if(!settingsColor(names[i],*current[i],colors[i])){newsServer.send(400,"text/plain; charset=utf-8","颜色格式应为 #RRGGBB");return;}
  int brightness,rotation,weatherMinutes,newsMinutes,limit,scroll,categories,source,show;
  bool valid=settingsInt("brightness",LCD_BL_PWM,0,100,brightness)&&settingsInt("rotation",LCD_Rotation,0,3,rotation)
    &&settingsInt("weather_minutes",updateweather_time,10,60,weatherMinutes)&&settingsInt("news_minutes",newsPollMs/60000,10,30,newsMinutes)
    &&settingsInt("news_limit",newsLimit,1,10,limit)&&settingsInt("scroll_ms",newsScrollMs,20,70,scroll)
    &&settingsInt("categories",newsCategories,1,15,categories)&&settingsInt("source_mode",newsSourceMode,0,1,source)
    &&settingsInt("show_info",newsShowInfo,0,1,show);
  if(!valid || (newsMinutes!=10&&newsMinutes!=30)){newsServer.send(400,"text/plain; charset=utf-8","设置值超出有效范围");return;}
  String city=newsServer.hasArg("city_code")?newsServer.arg("city_code"):cityCode;
  if(city.length()!=9 || city.toInt()<101000000 || city.toInt()>101999999){newsServer.send(400,"text/plain; charset=utf-8","请输入有效的九位天气城市代码");return;}
  for(unsigned i=0;i<city.length();++i)if(!isdigit(city[i])){newsServer.send(400,"text/plain; charset=utf-8","城市代码应为数字");return;}
  String feed=newsServer.hasArg("feed")?newsServer.arg("feed"):newsFeed;feed.trim();
  if(!validNewsFeed(feed)){newsServer.send(400,"text/plain; charset=utf-8","请输入有效的 GitHub Pages HTTPS 或局域网新闻接口");return;}
  bool rotateChanged=rotation!=LCD_Rotation,cityChanged=city!=cityCode;
  bool newsChanged=feed!=newsFeed||newsMinutes*60000U!=newsPollMs||limit!=newsLimit||categories!=newsCategories||source!=newsSourceMode;
  const char* keys[]={"date_rgb","hour_rgb","min_rgb","sec_rgb","news_rgb"};
  for(int i=0;i<5;++i)if(*current[i]!=colors[i]){*current[i]=colors[i];newsPrefs.putUInt(keys[i],colors[i]);}
  updateTextColors();
  LCD_BL_PWM=brightness;LCD_Rotation=rotation;
  bool eepromChanged=false;
  if(EEPROM.read(BL_addr)!=brightness){EEPROM.write(BL_addr,brightness);eepromChanged=true;}
  if(EEPROM.read(Ro_addr)!=rotation){EEPROM.write(Ro_addr,rotation);eepromChanged=true;}
  if(cityChanged){int value=city.toInt();for(int i=0;i<5;++i){EEPROM.write(CC_addr+i,value%100);value/=100;}cityCode=city;eepromChanged=true;}
  if(eepromChanged)EEPROM.commit();
  analogWrite(LCD_BL_PIN,255-(LCD_BL_PWM*255/100));
  updateweather_time=weatherMinutes;newsPrefs.putUInt("weather_min",weatherMinutes);
  reflash_openWifi.setInterval(weatherMinutes*60000U);
  xSemaphoreTake(newsLock,portMAX_DELAY);
  newsFeed=feed;newsPollMs=newsMinutes*60000U;newsLimit=limit;newsCategories=categories;newsSourceMode=source;
  xSemaphoreGive(newsLock);
  newsShowInfo=show;newsScrollMs=scroll;
  newsPrefs.putString("feed",feed);newsPrefs.putUInt("poll_ms",newsPollMs);newsPrefs.putUInt("limit",limit);
  newsPrefs.putUInt("categories",categories);newsPrefs.putUInt("source_mode",source);newsPrefs.putUInt("scroll_ms",scroll);newsPrefs.putBool("show_info",show);
  newsCurrent="";newsForceRedraw=true;newsScreenRefresh=rotateChanged;
  if(cityChanged||rotateChanged)Wifi_en=1;
  if(newsChanged&&newsWorker)xTaskNotifyGive(newsWorker);
  newsServer.send(200,"application/json","{\"saved\":true}");
}
