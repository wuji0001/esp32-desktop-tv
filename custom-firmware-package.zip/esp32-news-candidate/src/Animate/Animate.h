#ifndef ANIMATE_h
#define ANIMATE_h

// extern int DHT_img_flag; // DHT传感器使用标志位
#include <stdint.h>


void imgAnim(const uint8_t **Animate_value, uint32_t *Animate_size); //动画函数

#endif