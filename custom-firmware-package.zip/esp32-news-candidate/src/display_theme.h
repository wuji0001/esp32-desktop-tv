#pragma once
#include <stdint.h>
// This panel uses BGR order. Settings expose the visible RGB color.
static constexpr uint16_t panelTextColor(uint8_t r, uint8_t g, uint8_t b) {
  return uint16_t((uint16_t(b & 0xF8) << 8) | (uint16_t(g & 0xFC) << 3) | (r >> 3));
}
static uint16_t panelRgb(uint32_t rgb) { return panelTextColor(rgb >> 16, rgb >> 8, rgb); }
static uint32_t dateTextRgb=0xE58A72, hourTextRgb=0xFF0000, minuteTextRgb=0xFFFFFF;
static uint32_t secondTextRgb=0x2182D6, newsTextRgb=0xCEB8FF;
static uint16_t dateTextColor=panelRgb(dateTextRgb), hourTextColor=panelRgb(hourTextRgb);
static uint16_t minuteTextColor=panelRgb(minuteTextRgb), secondTextColor=panelRgb(secondTextRgb);
static uint16_t newsTextColor=panelRgb(newsTextRgb);
