#pragma once
#include <Preferences.h>
#include <WiFiClientSecure.h>
#include <sys/time.h>
#include "news_roots.h"
#include "news_text.h"

// Only the 150x30 banner is redrawn. All pixel drawing stays on loop().
static WebServer newsServer(80);
static TFT_eSprite newsSprite(&tft);
static constexpr int NEWS_MAX_ITEMS = 10;
static constexpr int NEWS_MAX_BYTES = 3072;
static String newsItems[NEWS_MAX_ITEMS];
static String newsDate;
static uint32_t newsDateChecked = 0;
static int newsCount = 0, newsSlot = 0;
static String newsCurrent;
static int newsWidth = 0;
static bool newsMarquee = false, newsStale = false;
static uint32_t newsLastSync = 0;
static uint32_t newsPollMs = 600000;
static uint32_t newsScrollMs = 35;
static unsigned newsLimit=10, newsCategories=15, newsSourceMode=0;
static bool newsShowInfo=true, newsForceRedraw=false, newsScreenRefresh=false;
static uint32_t newsRestartAt=0;
static uint32_t newsStarted = 0, newsFrame = 0;
static bool newsAdvanceRequested = true;
static Preferences newsPrefs;
static QueueHandle_t newsQueue;
static SemaphoreHandle_t newsLock;
static TaskHandle_t newsWorker;
static String newsFeed;
static bool newsClockReady=false;
static String newsLastError;
struct NewsBatch { char text[NEWS_MAX_ITEMS][241]; char date[11]; char error[96]; int count; bool success; };
static bool validNewsFeed(const String& url) {
  if (url.length() > 180) return false;
  if(url.indexOf('@')>=0||url.indexOf('\n')>=0||url.indexOf('\r')>=0||url.indexOf(' ')>=0)return false;
  return url.length() == 0 || url.startsWith("http://192.168.") || url.startsWith("http://10.") || url.startsWith("https://wuji0001.github.io/esp32-desktop-tv/");
}
#include "news_settings.h"
static void fetchNewsWorker(void*) {
  for (;;) {
    xSemaphoreTake(newsLock, portMAX_DELAY);
    String feed = newsFeed;
    const unsigned limit=newsLimit, categories=newsCategories, sourceMode=newsSourceMode;
    const bool secureFeed=feed.startsWith("https://");
    if(feed.length()&&!secureFeed)feed+=(feed.indexOf('?')>=0?"&":"?")+String("limit=")+limit+"&categories="+categories+"&sources="+(sourceMode?"bing":"international");
    xSemaphoreGive(newsLock);
    if(secureFeed&&!newsClockReady){ulTaskNotifyTake(pdTRUE,pdMS_TO_TICKS(1000));continue;}
    if (feed.length() && WiFi.status() == WL_CONNECTED) {
      NewsBatch batch = {};
      WiFiClient client;
      WiFiClientSecure secureClient;
      if(secureFeed){secureClient.setCACert(NEWS_ROOTS);secureClient.setHandshakeTimeout(15);}
      WiFiClient& transport=secureFeed?static_cast<WiFiClient&>(secureClient):client;
      HTTPClient http;
      http.setConnectTimeout(secureFeed?10000:3000); http.setTimeout(secureFeed?15000:3000); http.useHTTP10(true);
      const char* responseHeaders[] = {"X-Poll-Interval-Seconds", "X-News-Date"};
      http.collectHeaders(responseHeaders, 2);
      int code=0;
      if(http.begin(transport,feed)){http.addHeader("Accept-Encoding","identity");code=http.GET();}
      if(secureFeed && code==200 && http.getSize()>=0 && http.getSize()<=16384){
        String body=http.getString();JsonDocument doc;
        auto error=deserializeJson(doc,body);
        if(!error){
          String date=doc["date"].as<String>();date.toCharArray(batch.date,sizeof(batch.date));
          String seen[NEWS_MAX_ITEMS],publishers[NEWS_MAX_ITEMS];
          unsigned publisherCounts[NEWS_MAX_ITEMS]={};int publisherTotal=0;
          for(JsonObject item:doc["items"].as<JsonArray>()){
            unsigned category=item["c"]|0;bool bing=item["b"]|0;
            if(!(categories&category)||(sourceMode&&!bing))continue;
            String id=item["id"].as<String>(),text=item["t"].as<String>(),publisher=item["p"].as<String>();
            if(!id.length()||!text.length()||text.length()>240)continue;
            bool duplicate=false;for(int i=0;i<batch.count;++i)if(seen[i]==id)duplicate=true;
            if(duplicate)continue;
            int p=0;while(p<publisherTotal&&publishers[p]!=publisher)++p;
            if(p<publisherTotal&&publisherCounts[p]>=4)continue;
            if(p==publisherTotal){publishers[p]=publisher;++publisherTotal;}
            ++publisherCounts[p];seen[batch.count]=id;
            text.toCharArray(batch.text[batch.count++],241);
            if(batch.count>=int(limit))break;
          }
          batch.success=date.length()==10&&date[4]=='-'&&date[7]=='-';
        }else snprintf(batch.error,sizeof(batch.error),"JSON: %s",error.c_str());
      }else if (!secureFeed && code==200 && http.getSize() >= 0 && http.getSize() <= NEWS_MAX_BYTES) {
        String date = http.header("X-News-Date");
        date.toCharArray(batch.date, sizeof(batch.date));
        auto stream = http.getStreamPtr();
        String line; size_t bytes = 0; uint32_t began = millis();
        const size_t expected = http.getSize();
        while (bytes < expected && millis() - began < 4000 && (http.connected() || stream->available())) {
          if (!stream->available()) { vTaskDelay(pdMS_TO_TICKS(5)); continue; }
          char c = stream->read(); ++bytes;
          if (c == '\n') {
            line.trim();
            if (line.length() && line.length() <= 240 && batch.count < NEWS_MAX_ITEMS)
              line.toCharArray(batch.text[batch.count++], 241);
            line = "";
          } else if (line.length() < 241) line += c;
        }
        line.trim();
        if (line.length() && line.length() <= 240 && batch.count < NEWS_MAX_ITEMS)
          line.toCharArray(batch.text[batch.count++], 241);
        // An empty, dated batch is valid: do not retain yesterday's headlines.
        batch.success = bytes == expected && date.length() == 10 && date[4] == '-' && date[7] == '-';
      }
      if(!batch.success&&!batch.error[0])snprintf(batch.error,sizeof(batch.error),"News HTTP %d, length %d",code,http.getSize());
      http.end();
      xQueueOverwrite(newsQueue, &batch);
    }
    ulTaskNotifyTake(pdTRUE, pdMS_TO_TICKS(newsPollMs));
  }
}
static void setupNews() {
  newsPrefs.begin("news-banner", false);
  loadNewsSettings();
  newsFeed = newsPrefs.getString("feed", "");
  if (!validNewsFeed(newsFeed)) newsFeed = "";
  newsQueue = xQueueCreate(1, sizeof(NewsBatch));
  newsLock = xSemaphoreCreateMutex();
  newsSprite.setColorDepth(8);
  if (!newsSprite.createSprite(150, 30) || !newsQueue || !newsLock) {
    Serial.println("NEWS: allocation failed"); return;
  }
  newsSprite.setTextWrap(false); newsSprite.setTextDatum(TL_DATUM);
  newsServer.on("/", HTTP_GET, []() {
    newsServer.send_P(200, "text/html; charset=utf-8", NEWS_SETTINGS_PAGE);
  });
  newsServer.on("/status", HTTP_GET, []() {
    JsonDocument doc; doc["feed"] = newsFeed; doc["count"] = newsCount;
    doc["stale"] = newsStale; doc["last_sync_ms"] = newsLastSync;
    doc["last_error"]=newsLastError;
    doc["poll_interval_seconds"] = newsPollMs / 1000;
    doc["news_date"] = newsDate; doc["max_items"] = NEWS_MAX_ITEMS;
    doc["firmware"] = "SD2 C3 News compact";
    doc["theme"] = "adjustable-date-lavender";
    char dateColorHex[8]; snprintf(dateColorHex, sizeof(dateColorHex), "#%06lX", (unsigned long)dateTextRgb);
    doc["date_color"] = dateColorHex;
    doc["font_bytes"] = NEWS_FONT_GLYPHS * 43U;
    doc["font_glyphs"] = NEWS_FONT_GLYPHS;
    doc["free_heap"] = ESP.getFreeHeap();
    doc["minimum_free_heap"] = ESP.getMinFreeHeap();
    addNewsSettings(doc);
    String body; serializeJson(doc, body); newsServer.send(200, "application/json", body);
  });
  newsServer.on("/feed", HTTP_POST, []() {
    String url = newsServer.arg("url"); url.trim();
    if (!validNewsFeed(url)) { newsServer.send(400, "text/plain", "Use the GitHub Pages HTTPS feed or a LAN HTTP feed."); return; }
    xSemaphoreTake(newsLock, portMAX_DELAY); newsFeed = url; xSemaphoreGive(newsLock);
    newsPrefs.putString("feed", url); xTaskNotifyGive(newsWorker);
    newsServer.sendHeader("Location", "/"); newsServer.send(303);
  });
  newsServer.on("/appearance", HTTP_POST, []() {
    String hex = newsServer.arg("date_color");
    if (hex.length() != 7 || hex[0] != '#') { newsServer.send(400, "text/plain", "Expected #RRGGBB"); return; }
    for (int i=1; i<7; ++i) if (!isxdigit(hex[i])) { newsServer.send(400, "text/plain", "Invalid color"); return; }
    dateTextRgb = strtoul(hex.c_str()+1, nullptr, 16);
    dateTextColor = panelTextColor(dateTextRgb >> 16, dateTextRgb >> 8, dateTextRgb);
    newsPrefs.putUInt("date_rgb", dateTextRgb);
    newsServer.send(200, "application/json", "{\"saved\":true}");
  });
  newsServer.on("/settings",HTTP_POST,handleNewsSettings);
  newsServer.on("/refresh",HTTP_POST,[](){Wifi_en=1;xTaskNotifyGive(newsWorker);newsServer.send(202,"application/json","{\"refreshing\":true}");});
  newsServer.on("/restart",HTTP_POST,[](){newsServer.send(202,"application/json","{\"restarting\":true}");newsRestartAt=millis()+500;});
  newsServer.begin();
  xTaskCreate(fetchNewsWorker, "news-feed", 8192, nullptr, 1, &newsWorker);
}
static void serviceNews() {
  if (!newsQueue || !newsLock || !newsWorker) return;
  newsServer.handleClient();
  if(!newsClockReady && year()>=2026){timeval clock={};clock.tv_sec=now()-8*3600;settimeofday(&clock,nullptr);newsClockReady=true;xTaskNotifyGive(newsWorker);}
  if(newsRestartAt && int32_t(millis()-newsRestartAt)>=0)ESP.restart();
  if(newsScreenRefresh){newsScreenRefresh=false;tft.setRotation(LCD_Rotation);tft.fillScreen(bgColor);TJpgDec.drawJpg(15,183,temperature,sizeof(temperature));TJpgDec.drawJpg(15,213,humidity,sizeof(humidity));}
  if(newsForceRedraw){newsForceRedraw=false;digitalClockDisplay(1);}
  NewsBatch batch;
  if (xQueueReceive(newsQueue, &batch, 0) == pdTRUE) {
    newsStale = !batch.success;
    newsLastError=batch.error;
    if (batch.success) {
      newsLastSync = millis(); newsCount = batch.count;
      newsDate = batch.date;
      for (int i=0; i<newsCount; ++i) newsItems[i] = batch.text[i];
      // Also discard a currently scrolling headline removed by this refresh.
      if (newsMarquee) newsCurrent = "";
    }
  }
  uint32_t nowMs = millis();
  if (nowMs - newsDateChecked >= 1000) {
    newsDateChecked = nowMs;
    if (year() >= 2026 && newsDate.length()) {
      char today[11];
      snprintf(today, sizeof(today), "%04d-%02d-%02d", year(), month(), day());
      if (newsDate != today) {
        newsCount = 0; newsDate = "";
        for (int i=0; i<NEWS_MAX_ITEMS; ++i) newsItems[i] = "";
        if (newsMarquee) newsCurrent = "";
        xTaskNotifyGive(newsWorker);
      }
    }
  }
  uint32_t duration = newsMarquee ? 2000 + (newsWidth + 150) * newsScrollMs : 3500;
  if (newsCurrent.isEmpty() || (newsAdvanceRequested && nowMs - newsStarted >= duration)) {
    const int infoSlots=newsShowInfo?7:0;
    const int slots = max(1,infoSlots + newsCount);
    newsSlot = (newsSlot + 1) % slots;
    if(!infoSlots&&!newsCount)newsCurrent="暂无当天新闻";
    else if (newsShowInfo && newsSlot < 6) newsCurrent = scrollText[newsSlot];
    else if (newsShowInfo && newsSlot == 6) newsCurrent = WiFi.localIP().toString();
    else newsCurrent = (newsStale ? String("缓存 ") : String("")) + newsItems[newsSlot-infoSlots];
    newsMarquee = newsSlot >= infoSlots && newsCount>0;
    newsWidth = newsTextWidth(newsCurrent);
    newsStarted = nowMs; newsAdvanceRequested = false;
  }
  if (nowMs - newsFrame < newsScrollMs) return;
  newsFrame = nowMs;
  int x = newsMarquee ? 150 - int((nowMs-newsStarted > 1000 ? nowMs-newsStarted-1000 : 0)/newsScrollMs) : (150-newsWidth)/2;
  newsSprite.fillSprite(bgColor);
  drawNewsText(newsSprite, newsCurrent, x, 3, newsMarquee ? newsTextColor : TFT_WHITE);
  newsSprite.pushSprite(10, 45);
}
