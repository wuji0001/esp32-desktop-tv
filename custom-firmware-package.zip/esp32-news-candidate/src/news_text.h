#pragma once
#include "font/NewsCompact16.h"

static uint16_t nextNewsCode(const char*& text) {
  uint8_t lead = uint8_t(*text++);
  if (lead < 0x80) return lead;
  int remaining = (lead & 0xE0) == 0xC0 ? 1 : (lead & 0xF0) == 0xE0 ? 2 : (lead & 0xF8) == 0xF0 ? 3 : 0;
  if (!remaining) return 0x25A1;
  uint32_t code = lead & (remaining == 1 ? 0x1F : remaining == 2 ? 0x0F : 0x07);
  for (int i=0; i<remaining; ++i) {
    if (!*text || (uint8_t(*text) & 0xC0) != 0x80) return 0x25A1;
    code = (code << 6) | (uint8_t(*text++) & 0x3F);
  }
  return code > 0xFFFF ? 0x25A1 : uint16_t(code);
}
static int newsGlyphIndex(uint16_t code) {
  int lo = 0, hi = NEWS_FONT_GLYPHS - 1;
  while (lo <= hi) {
    int mid = (lo + hi) / 2;
    uint16_t value = pgm_read_word(newsFontCodes + mid);
    if (value == code) return mid;
    if (value < code) lo = mid + 1; else hi = mid - 1;
  }
  return -1;
}
static int newsTextWidth(const String& value) {
  int width = 0; const char* text = value.c_str();
  while (*text) {
    int index = newsGlyphIndex(nextNewsCode(text));
    width += index < 0 ? 16 : pgm_read_byte(newsFontAdvance + index);
  }
  return width;
}
static void drawNewsText(TFT_eSprite& sprite, const String& value, int x, int y, uint16_t color) {
  const char* text = value.c_str();
  while (*text && x < sprite.width()) {
    int index = newsGlyphIndex(nextNewsCode(text));
    int advance = index < 0 ? 16 : pgm_read_byte(newsFontAdvance + index);
    if (x + 16 > 0) {
      if (index < 0) sprite.drawRect(x+2, y+3, 11, 13, color);
      else for (int row=0; row<NEWS_FONT_HEIGHT; ++row) {
        uint16_t bits = pgm_read_word(newsFontRows + index * NEWS_FONT_HEIGHT + row);
        int start = -1;
        for (int column=0; column<=16; ++column) {
          bool on = column < 16 && (bits & (0x8000 >> column));
          if (on && start < 0) start = column;
          if (!on && start >= 0) { sprite.drawFastHLine(x+start, y+row, column-start, color); start = -1; }
        }
      }
    }
    x += advance;
  }
}
