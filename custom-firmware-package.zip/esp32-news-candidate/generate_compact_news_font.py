"""Pack the existing GB2312 coverage as a 16x20, 1-bit font (SIL OFL source)."""
import json,math,sys,struct
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont
base=Path(__file__).parent
font=ImageFont.truetype(sys.argv[1],16)
chars=set(range(32,127))|set(range(0x2000,0x2070))|set(range(0x3000,0x3040))
for a in range(0xa1,0xf8):
 for b in range(0xa1,0xff):
  try:chars.add(ord(bytes([a,b]).decode('gb2312')))
  except UnicodeError:pass
codes=sorted(chars);rows=[];adv=[]
preview=Image.new('RGB',(480,100),'#10151e');pd=ImageDraw.Draw(preview)
samples='科技与AI 全球突发 金融 医疗 玫瑰粉薰衣草紫'
for code in codes:
 im=Image.new('L',(16,20));ImageDraw.Draw(im).text((0,15),chr(code),font=font,anchor='ls',fill=255)
 for y in range(20):rows.append(sum((1<<(15-x)) for x in range(16) if im.getpixel((x,y))>=96))
 adv.append(min(16,max(1,math.ceil(font.getlength(chr(code))))))
out=base/'src/font/NewsCompact16.h'
with out.open('w') as f:
 f.write('// Generated from OFL Noto Sans CJK. See NEWS-FONT-LICENSE.txt.\n#pragma once\n#include <pgmspace.h>\n')
 f.write(f'static constexpr uint16_t NEWS_FONT_GLYPHS = {len(codes)};\nstatic constexpr uint8_t NEWS_FONT_HEIGHT = 20;\n')
 for name,typ,data in [('newsFontCodes','uint16_t',codes),('newsFontAdvance','uint8_t',adv),('newsFontRows','uint16_t',rows)]:
  f.write(f'const {typ} {name}[] PROGMEM = {{\n')
  for i in range(0,len(data),24):f.write(','.join(map(str,data[i:i+24]))+',\n')
  f.write('};\n')
for i,c in enumerate(samples):
 idx=codes.index(ord(c));x=8+(i%26)*18;y=4+(i//26)*24
 for yy,row in enumerate(rows[idx*20:(idx+1)*20]):
  for xx in range(16):
   if row&(1<<(15-xx)):pd.point((x+xx,y+yy),fill='#ceb8ff')
preview.resize((960,200)).save(base/'compact-font-preview.png')
old=base/'src/font/NewsFont16.h'
oldraw=bytes(map(int,old.read_text().split('{',1)[1].rsplit('}',1)[0].replace('\n','').strip(',').split(','))) if old.exists() else bytes(2131651)
print(json.dumps({'glyphs':len(codes),'old_font_bytes':len(oldraw),'compact_font_bytes':len(codes)*43,'saved_flash_bytes':len(oldraw)-len(codes)*43},indent=2))
(base/'compact-font-stats.json').write_text(json.dumps({'glyphs':len(codes),'old_font_bytes':len(oldraw),'compact_font_bytes':len(codes)*43},indent=2))
